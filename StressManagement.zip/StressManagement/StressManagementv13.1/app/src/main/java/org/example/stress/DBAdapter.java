// ------------------------------------ DBADapter.java ---------------------------------------------

// TODO: Change the package to match your project.
package org.example.stress;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DBAdapter {

	private static final String TAG = "DBAdapter";
	public static final String KEY_ROWID = "_id";
	public static final String KEY_SOURCES = "sources";
	public static final String KEY_STRESS = "stress";
	public static final String KEY_SYMPTOMS = "symptoms";
	public static final String KEY_NOTES = "notes";
	public static final String KEY_DATE = "date";

	public static final String[] ALL_KEYS = new String[] {KEY_ROWID, KEY_SOURCES, KEY_STRESS, KEY_SYMPTOMS, KEY_NOTES, KEY_DATE};

	public static final String DATABASE_NAME = "MyDb";
	public static final String DATABASE_TABLE = "mainTable";
	public static final int DATABASE_VERSION = 2;	
	
	private static final String DATABASE_CREATE_SQL =
			"create table " + DATABASE_TABLE 
			+ " (" + KEY_ROWID + " integer primary key autoincrement, "
			+ KEY_SOURCES + " string not null, "
			+ KEY_STRESS + " integer not null, "
			+ KEY_SYMPTOMS + " string not null, "
			+ KEY_NOTES + " string not null, "
			+ KEY_DATE + " string not null"
			+ ");";
	

	private final Context context;
	
	private DatabaseHelper myDBHelper;
	private SQLiteDatabase db;

	
	public DBAdapter(Context ctx) {
		this.context = ctx;
		myDBHelper = new DatabaseHelper(context);
	}
	

	public DBAdapter open() {
		db = myDBHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		myDBHelper.close();
	}

	public long insertRow(String sources, int stress, String symptoms, String notes, String date) {

		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_SOURCES, sources);
		initialValues.put(KEY_STRESS, stress);
		initialValues.put(KEY_SYMPTOMS, symptoms);
		initialValues.put(KEY_NOTES, notes);
		initialValues.put(KEY_DATE, date);

		return db.insert(DATABASE_TABLE, null, initialValues);
	}
	

	public boolean deleteRow(long rowId) {
		String where = KEY_ROWID + "=" + rowId;
		return db.delete(DATABASE_TABLE, where, null) != 0;
	}


	public void deleteAll() {
		Cursor c = getAllRows();
		long rowId = c.getColumnIndexOrThrow(KEY_ROWID);
		if (c.moveToFirst()) {
			do {
				deleteRow(c.getLong((int) rowId));				
			} while (c.moveToNext());
		}
		c.close();
	}
	

	public Cursor getAllRows() {
		String where = null;
		Cursor c = 	db.query(true, DATABASE_TABLE, ALL_KEYS,
				where, null, null, null, null, null);
		if (c != null) {
			c.moveToFirst();
		}
		return c;
	}


	public Cursor getRow(long rowId) {
		String where = KEY_ROWID + "=" + rowId;
		Cursor c = 	db.query(true, DATABASE_TABLE, ALL_KEYS,
						where, null, null, null, null, null);
		if (c != null) {
			c.moveToFirst();
		}
		return c;
	}
	


	public int getSizeOfDB(){
		Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM mainTable;",null);
		int count = 0;
		if(null != cursor)
			if (cursor.getCount() > 0){
				cursor.moveToFirst();
				count = cursor.getInt(0);
			}
		cursor.close();
		return count;
	}


	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase _db) {
			_db.execSQL(DATABASE_CREATE_SQL);			
		}

		@Override
		public void onUpgrade(SQLiteDatabase _db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading application's database from version " + oldVersion
					+ " to " + newVersion + ", which will destroy all old data!");

			_db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);

			onCreate(_db);
		}
	}
}
