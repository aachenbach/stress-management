package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Date;


public class AddEntry extends Activity implements OnClickListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addentry);

        View submitButton = findViewById(R.id.submit_button);
        submitButton.setOnClickListener(this);

    }

    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.submit_button:

                String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date()); //set date to todays date

                EditText edText1 = (EditText) findViewById(R.id.text_source);
                EditText edText2 = (EditText) findViewById(R.id.text_symptoms);
                EditText edText3 = (EditText) findViewById(R.id.text_notes);

                String sources = edText1.getText().toString();
                String symptoms = edText2.getText().toString();
                String notes = edText3.getText().toString();

                ((Data)this.getApplication()).setDate(date);
                ((Data)this.getApplication()).setSources(sources);
                ((Data)this.getApplication()).setSymptoms(symptoms);
                ((Data)this.getApplication()).setNotes(notes);
                ((Data)this.getApplication()).toggleNewEntryFlag();

                Intent i = new Intent(this, Journal.class); //intent object is android code, passes control between classes
                startActivity(i); //Each activity must be activated by the intent object
                finish();
                break;

        }
    }
}