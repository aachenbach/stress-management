package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class Results extends Activity implements OnClickListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.results);

        View continueButton = findViewById(R.id.return_button); //link to the layout file
        continueButton.setOnClickListener(this); //<--enable the button

        View addEntryButton = findViewById(R.id.diary_entry_button); //link to the layout file
        addEntryButton.setOnClickListener(this); //<--enable the button

        int temp = ((Data) this.getApplication()).getStressLevel();
        ((Data) this.getApplication()).setStressLevel(temp); //double score in accordance with the rules for the test

        TextView myTextView = (TextView) findViewById(R.id.score);
        myTextView.setText("Your score is " + temp);

        //alter result graphic
        final View stressImage = findViewById(R.id.imageView2);
        final View greenStress = findViewById(R.id.green);
        final Drawable greenStressBG = greenStress.getBackground();
        final View yellowStress = findViewById(R.id.yellow);
        final Drawable yellowStressBG = yellowStress.getBackground();
        final View orangeStress = findViewById(R.id.orange);
        final Drawable orangeStressBG = orangeStress.getBackground();
        final View redOrangeStress = findViewById(R.id.red_orange);
        final Drawable redOrangeStressBG = redOrangeStress.getBackground();
        final View redStress = findViewById(R.id.red);
        final Drawable redStressBG = redStress.getBackground();

        if (0 <= temp && temp < 15) {stressImage.setBackgroundDrawable(greenStressBG);}
        else if (temp > 14 && temp < 19) {stressImage.setBackgroundDrawable(yellowStressBG);}
        else if (temp > 18 && temp < 26) {stressImage.setBackgroundDrawable(orangeStressBG);}
        else if (temp > 25 && temp < 34) {stressImage.setBackgroundDrawable(redOrangeStressBG);}
        else {stressImage.setBackgroundDrawable(redStressBG);}
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.return_button:
                ((Data)this.getApplication()).setStressLevel(0);
                Intent i1 = new Intent(this, MainMenu.class);
                startActivity(i1);
                finish();
                break;

            case R.id.diary_entry_button:
                //((Data)this.getApplication()).setStressLevel(0);
                Intent i2 = new Intent(this, AddEntry.class); //intent object is android code, passes control between classes
                startActivity(i2); //Each activity must be activated by the intent object
                finish();
                break;

        }
    }
}