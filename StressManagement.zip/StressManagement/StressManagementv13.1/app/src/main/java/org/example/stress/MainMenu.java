package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;

public class MainMenu extends Activity implements OnClickListener {



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu);
        Bundle Question = getIntent().getExtras();

        // Set up click listeners for all the buttons
        final View continueButton = findViewById(R.id.survey_button); //link to the layout file
        continueButton.setOnClickListener(this); //<--enable the button
        final View newButton = findViewById(R.id.log_button);
        newButton.setOnClickListener(this);
        final View aboutButton = findViewById(R.id.about_button);
        aboutButton.setOnClickListener(this);
        final View planButton = findViewById(R.id.plan_button);
        planButton.setOnClickListener(this);
        final View pressedButton = findViewById(R.id.pressedButton); //<--used for my_pressed_button background

        //change button color on touch
        final Drawable originalBackground = continueButton.getBackground();
        final Drawable newBackground = pressedButton.getBackground();
        continueButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    continueButton.setBackgroundDrawable(originalBackground);
                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    continueButton.setBackgroundDrawable(newBackground);
                }
                return false;
            }
        });

        newButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    newButton.setBackgroundDrawable(originalBackground);
                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    newButton.setBackgroundDrawable(newBackground);
                }
                return false;
            }
        });

        aboutButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    aboutButton.setBackgroundDrawable(originalBackground);
                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    aboutButton.setBackgroundDrawable(newBackground);
                }
                return false;
            }
        });

        planButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    planButton.setBackgroundDrawable(originalBackground);
                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    planButton.setBackgroundDrawable(newBackground);
                }
                return false;
            }
        });



    }



    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.survey_button:
                ((Data)this.getApplication()).setStressLevel(0);
                Intent i1 = new Intent(this, Question1.class); //intent object is android code, passes control between classes
                startActivity(i1); //Each activity must be activated by the intent object
                break;

            case R.id.log_button:
                Intent i2 = new Intent(this, Journal.class); //intent object is android code, passes control between classes
                startActivity(i2); //Each activity must be activated by the intent object
                break;

            case R.id.about_button:
                Intent i3 = new Intent(this, About.class); //intent object is android code, passes control between classes
                startActivity(i3); //Each activity must be activated by the intent object
                break;

            case R.id.plan_button:
                Intent i4 = new Intent(this, SelfCarePlan.class); //intent object is android code, passes control between classes
                startActivity(i4); //Each activity must be activated by the intent object
                break;
        }
    }
}
