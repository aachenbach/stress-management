package org.example.stress;

import android.database.Cursor;
import android.os.Bundle;
import android.app.Activity;

import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;
import com.jjoe64.graphview.helper.StaticLabelsFormatter;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;



public class Graph extends Activity {

    DBAdapter myDb;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graph);
        openDB();
        drawGraph();
    }

    public void drawGraph(){

        int sizeOfDB = myDb.getSizeOfDB(); //TODO here is the problem area
        GraphView graph = (GraphView) findViewById(R.id.graph);



        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setMinY(0);
        graph.getViewport().setMaxY(45);
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(1);
        graph.getViewport().setMaxX(sizeOfDB);


        ArrayList<Integer> list_entryNumber=new ArrayList<Integer>(){};
        ArrayList<Integer> list_stressLevel=new ArrayList<Integer>(){};

        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(new DataPoint[] {
                //empty  to start with

        });


        for (int j = 0; j < sizeOfDB; j++)
        {
            list_entryNumber.add(j+1);
        }

        for (int j = 0; j < sizeOfDB; j++)
        {

            Cursor cursor = myDb.getRow(j+1);


                int stress = cursor.getInt(cursor.getColumnIndex("stress"));
                list_stressLevel.add(stress);


            cursor.close();


        }


        for (int j = 0; j < sizeOfDB; j++)
        {
            DataPoint data = new DataPoint(list_entryNumber.get(j), list_stressLevel.get(j));
            series.appendData(data, true, 10);
        }

        graph.addSeries(series);


    }

    protected void onDestroy() {
        super.onDestroy();
        closeDB();
    }

    private void openDB() {
        myDb = new DBAdapter(this);
        myDb.open();
    }
    private void closeDB() {
        myDb.close();
    }



}


